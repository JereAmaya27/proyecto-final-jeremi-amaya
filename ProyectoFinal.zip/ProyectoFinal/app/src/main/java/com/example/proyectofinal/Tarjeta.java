package com.example.proyectofinal;

import android.net.Uri;

public class Tarjeta {
    private String titulo;
    private Uri imagenUri;

    public Tarjeta(String titulo, Uri imagenUri) {
        this.titulo = titulo;
        this.imagenUri = imagenUri;
    }

    public String getTitulo() {
        return titulo;
    }

    public Uri getImagenUri() {
        return imagenUri;
    }
}


