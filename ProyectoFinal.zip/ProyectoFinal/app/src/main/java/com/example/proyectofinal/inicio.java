package com.example.proyectofinal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class inicio extends AppCompatActivity {

    private List<Tarjeta> tarjetaList;
    private TarjetaAdapter tarjetaAdapter;
    private static final int REQUEST_CODE_AGREGAR_TARJETA = 1;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inicio);

        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnAgregar = findViewById(R.id.btnAgregar);
        btnLogout = findViewById(R.id.btnLogout);

        btnLogin.setOnClickListener(v -> {
            Intent intent = new Intent(inicio.this, login.class);
            startActivity(intent); // Inicia la actividad de login
        });

        boolean isLoggedIn = checkIfUserIsLoggedIn();

        if (isLoggedIn) {
            // Si el usuario está autenticado, mostramos el botón "Agregar"
            btnAgregar.setVisibility(View.VISIBLE);
            btnLogout.setVisibility(View.VISIBLE);
        } else {
            // Si no, mantenemos el botón oculto
            btnAgregar.setVisibility(View.GONE);
            btnLogout.setVisibility(View.GONE);
        }
        btnLogout.setOnClickListener(v -> {
            // Eliminar el estado de inicio de sesión
            SharedPreferences preferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("isLoggedIn", false); // Marcamos que el usuario no está conectado
            editor.apply();  // Guardamos los cambios

            // Ocultar los botones de "Agregar" y "Cerrar sesión"
            btnAgregar.setVisibility(View.GONE);
            btnLogout.setVisibility(View.GONE);

            // Regresar al LoginActivity
            Intent intent = new Intent(inicio.this, login.class);
            startActivity(intent);
            finish(); // Cierra la actividad actual
        });

        btnAgregar.setOnClickListener(v -> {
            // Lógica para agregar CardViews
            Intent intent = new Intent(inicio.this, agregarinfo.class); // Suponiendo que tienes esta actividad
            startActivity(intent);
        });


        tarjetaList = new ArrayList<>();
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        tarjetaAdapter = new TarjetaAdapter(this, tarjetaList);
        recyclerView.setAdapter(tarjetaAdapter);

        findViewById(R.id.btnAgregar).setOnClickListener(v -> {
            Intent intent = new Intent(inicio.this, agregarinfo.class);
            startActivityForResult(intent, REQUEST_CODE_AGREGAR_TARJETA);
        });


        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(inicio.this, agregarinfo.class);
                startActivity(intent);
            }
        });
    }
    private boolean checkIfUserIsLoggedIn() {
        // Obtener las SharedPreferences donde almacenamos el estado de inicio de sesión
        SharedPreferences preferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        // Verificar si el usuario está conectado. El valor por defecto es `false`.
        return preferences.getBoolean("isLoggedIn", false);
    }





    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_AGREGAR_TARJETA && resultCode == RESULT_OK && data != null) {
            String titulo = data.getStringExtra("titulo");
            Uri imagenUri = data.getParcelableExtra("imagenUri");

            Tarjeta nuevaTarjeta = new Tarjeta(titulo, imagenUri);
            tarjetaList.add(nuevaTarjeta);
            tarjetaAdapter.notifyDataSetChanged();
        }
    }
}