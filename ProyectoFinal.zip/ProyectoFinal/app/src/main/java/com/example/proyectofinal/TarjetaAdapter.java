package com.example.proyectofinal;
// TarjetaAdapter.java
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TarjetaAdapter extends RecyclerView.Adapter<TarjetaAdapter.TarjetaViewHolder> {

    private Context context;
    private List<Tarjeta> tarjetas;

    public TarjetaAdapter(Context context, List<Tarjeta> tarjetas) {
        this.context = context;
        this.tarjetas = tarjetas;
    }

    @NonNull
    @Override
    public TarjetaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cardview, parent, false);
        return new TarjetaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TarjetaViewHolder holder, int position) {
        Tarjeta tarjeta = tarjetas.get(position);
        holder.textViewTitulo.setText(tarjeta.getTitulo());
        holder.imageView.setImageURI(tarjeta.getImagenUri());
    }

    @Override
    public int getItemCount() {
        return tarjetas.size();
    }

    public static class TarjetaViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textViewTitulo;

        public TarjetaViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            textViewTitulo = itemView.findViewById(R.id.textViewTitulo);
        }
    }
}

