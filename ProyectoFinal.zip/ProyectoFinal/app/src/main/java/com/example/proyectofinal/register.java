package com.example.proyectofinal;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class register extends AppCompatActivity {


    private EditText etEmail, etPassword, etSecurityCode;
    private Button btnRegister;
    private UserDBManager userDBManager;
    private static final String SECURITY_CODE = "2727";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);

        userDBManager = new UserDBManager(this);
        userDBManager.open();

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etSecurityCode = findViewById(R.id.etSecurityCode); // Campo para ingresar el código de seguridad
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String securityCode = etSecurityCode.getText().toString().trim();

            // Verificar el código de seguridad
            if (securityCode.equals(SECURITY_CODE)) {
                // Si el código es correcto, proceder con el registro
                if (userDBManager.addUser(email, password) != -1) {
                    Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                    finish(); // Cierra la actividad de registro y regresa al login
                } else {
                    Toast.makeText(this, "Error al registrar usuario", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Si el código es incorrecto, mostrar mensaje de error
                Toast.makeText(this, "Código de seguridad incorrecto", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDBManager.close();
    }
    }
