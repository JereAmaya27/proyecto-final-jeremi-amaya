package com.example.proyectofinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class UserDBManager {

    private SQLiteDatabase database;
    private DBHelper dbHelper;

    // Constructor
    public UserDBManager(Context context) {
        dbHelper = new DBHelper(context);
    }

    // Abrir la base de datos en modo escritura
    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    // Cerrar la base de datos
    public void close() {
        dbHelper.close();
    }

    // Método para agregar un nuevo usuario
    public long addUser(String email, String password) {
        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_EMAIL, email);      // Referencia a la columna 'email'
        values.put(DBHelper.COLUMN_PASSWORD, password); // Referencia a la columna 'password'

        // Insertar un nuevo registro en la tabla de usuarios
        return database.insert(DBHelper.TABLE_USERS, null, values);
    }

    // Método para verificar si el usuario existe en la base de datos
    public boolean checkUser(String email, String password) {
        // Definir las columnas que se quieren obtener
        String[] columns = {DBHelper.COLUMN_EMAIL, DBHelper.COLUMN_PASSWORD};

        // Hacer la consulta para verificar si existe el usuario con el correo y la contraseña proporcionados
        Cursor cursor = database.query(
                DBHelper.TABLE_USERS,       // Tabla
                columns,                    // Columnas a seleccionar
                DBHelper.COLUMN_EMAIL + "=? AND " + DBHelper.COLUMN_PASSWORD + "=?", // Condición WHERE
                new String[]{email, password}, // Parámetros de la consulta
                null, null, null            // Sin agrupación, sin orden, sin límite
        );

        // Verificar si el cursor tiene resultados
        boolean userExists = cursor.getCount() > 0;
        cursor.close(); // Cerrar el cursor
        return userExists;
    }
}



